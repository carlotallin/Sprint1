package n1exercici2;

public class Person {
	
	//Fields
	private String name;
	private String surname ;
	private int age;
	
	public Person(String name, String surname, int age) {
		this.age = age;
		this.name=name;
		this.surname=surname;
	}
	
	//GETTERS
	public int getAge() {
		return age;
	}
	public String getName() {
		return name;
	}
	public String getSurname() {
		return surname;
	}

	//To String
	@Override
	public String toString() {
		return "Person: " + name + " " + surname + ", " + age + " years old.";
	}
	
}
