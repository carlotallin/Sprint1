package n1exercici2;

public class Main {

	public static void main(String[] args) {

		Person person1 = new Person("Carlota", "Llinàs", 24);
		GenericMethods<Object> exampleGeneric = new GenericMethods<Object>();
		exampleGeneric.printElements(person1, "String: hola.", 1597.4546);
	}

}
