package n1exercici6;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		List <String> list = new ArrayList<>();
		list.add("1");
		list.add("Hello");
		list.add("Bye");
		list.add("46739");
		list.add("Monday");
		list.add("324");
		list.add("9");
		list.add("Thanks");		
		System.out.println("Initial list: \n" + list + "\n");
		
		list.sort(Comparator.comparing(String::length));
		System.out.println("Ordered list: \n" + list);
	}

}
