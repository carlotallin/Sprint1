package n3exercici3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

public class Main {
	
	final static String filePath = "C:\\Users\\carlo\\eclipse-workspace\\S1.03.03\\src\\Countries.txt";
	//classificacio.txt = CountriesResults.txt;
	final static String outputFilePath = "C:\\Users\\carlo\\eclipse-workspace\\S1.03.03\\src\\CountriesResults.txt";
			
	public static void main(String[] args) {

		//HashMap creation.
		Map<String, String> capitalCountryHashMap = getHashMapFromTextFile();
		
		//Key:Country Value:Capital. To see if the data is written (Key/Value).
		/*for(Map.Entry<String,String> entry: capitalCountryHashMap.entrySet()) {
			System.out.println(entry.getKey()+ " " +entry.getValue());
		} */
	
		//Method = Test questions  + create doc with results
		capitalTest(capitalCountryHashMap);
				
	}
	
	public static void capitalTest(Map<String, String> capitalCountryHashMap)  {
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner (System.in);
		System.out.println("Introduce a user name:");
		String user = sc.nextLine();
		
		int points = 0;

		for(int i=1; i<11; i++){
			
			//Select a Random Country and it's capital
			Object[] countries = capitalCountryHashMap.keySet().toArray();
			int randomNumber = new Random().nextInt(countries.length);
			
			String country = (String) countries [randomNumber];
			Object[] capitals = capitalCountryHashMap.values().toArray();
			String capital = (String) capitals [randomNumber];
			
			System.out.println("\nWrite the capital of: "+ country +". (" + i +"/10).");
			String answer = sc.nextLine();
			
			  if (capital.equalsIgnoreCase(answer)) {
			  	points = points + 1;
			  	System.out.println("** You're right, +1 point! **\n");
			  }					  
		}
		
		System.out.println ("\n** The end!  You have a total of " + points + " points. ** ");
		
		//DOC WITH THE RESULTS
		Map<String, Integer> userPoints = new HashMap<String,Integer>();	
		Integer puntosInter = points;
		userPoints.put(user, puntosInter);

		File file = new File(outputFilePath);
	  	
        BufferedWriter bf = null;
	  
        try {
            bf = new BufferedWriter(new FileWriter(file));
            for (Map.Entry<String, Integer> entry: userPoints.entrySet()) {
                bf.write("User: " + entry.getKey() + "    -    Points: " + entry.getValue() + ".");
                bf.newLine();
            }
            bf.flush();
    	}
        catch (IOException e) {
            e.printStackTrace();
        }
    	finally {
    		try {  
                bf.close();
            }
            catch (Exception e) {
            }
        }
   }
		 
	private static Map<String, String> getHashMapFromTextFile() {
		
		Map<String,String> hashMap = new HashMap<String,String>();
		BufferedReader br = null;
		
		try {
			File file = new File(filePath);			
			br = new BufferedReader(new FileReader(file)); 
			String line = null;
			
			while ((line = br.readLine()) != null) {
				
				String[] part = line.split(" ");
				String country = part[0].trim();
				String capital = part[1].trim();
				
				if(!country.equals("")&&!capital.equals(""))
					hashMap.put(country, capital);
			}
			
		}
		catch (Exception e) {
				e.printStackTrace();
		}
		finally {
			if(br != null) {
				try {
					br.close();
				}catch (Exception e) {};
			}
		}
		return hashMap;
	}
}