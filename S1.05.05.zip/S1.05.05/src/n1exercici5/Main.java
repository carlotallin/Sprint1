package n1exercici5;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Main { 

	public static void main(String[] args) {
		
		Instrument guitar = new Instrument("guitar",50);

		Main.serializeObject(guitar,"C:/Users/carlo/OneDrive/Escritorio/Guitar.ser");
		Main.deserializeObject("C:/Users/carlo/OneDrive/Escritorio/Guitar.ser");
		
	}
	
	public static void serializeObject (Object object, String filePath) {
		
		try {
			
			ObjectOutputStream serializeArchive = new ObjectOutputStream(new FileOutputStream(filePath));			
			
			serializeArchive.writeObject(object); //Salta l'error però si que crea el document
			
			serializeArchive.close();
			
		}
			catch (Exception e) {
				System.out.println("There has been an error, please try again.");
			}
	}
	
	public static void deserializeObject (String filePath) {
			
		try {
			
			ObjectInputStream deserializeArchive = new ObjectInputStream(new FileInputStream(filePath));
		
			Object objectDeserialized = deserializeArchive.readObject();
								
			System.out.println(objectDeserialized.toString());
			
			deserializeArchive.close();
			
		} 
			catch (FileNotFoundException e) {
				System.out.println("File hasn't been found.");
			} 
			catch (IOException e) {
				System.out.println("There's an error.");
			}
			catch (ClassNotFoundException e) {
				System.out.println("Class hasn't been found.");
			}
	}
}
