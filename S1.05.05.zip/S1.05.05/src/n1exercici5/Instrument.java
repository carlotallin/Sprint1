package n1exercici5;

public class Instrument {

	//Fields
	protected String name;
	protected float price;
	
	//Constructor
	public Instrument (String name, float price) {
		this.name = name;
		this.price = price;
	}
	
	//Methods
	public String toString() {
		
		return "\n*** Instrument info ***" + "\nName: " + name + "\nPrice: " + price;
	}
}
