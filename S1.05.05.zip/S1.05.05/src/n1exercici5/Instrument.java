package n1exercici5;

import java.io.Serializable;

public class Instrument implements Serializable {

	//Fields
	private String name;
	private float price;
	
	//Constructor
	public Instrument (String name, float price) {
		this.name = name;
		this.price = price;
	}
	
	//GETTERS AND SETTERS
	public String getName() {
		return name;
	}
	
	public float getPrice() {
		return price;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setPrice(float price) {
		this.price = price;
	}
	
	//Methods
	public String toString() {
		return "\n*** Instrument info ***" + "\nName: " + name + "\nPrice: " + price;
	}
}
