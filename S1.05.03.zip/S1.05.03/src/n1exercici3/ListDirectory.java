package n1exercici3;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;

public class ListDirectory {

	public static void listDirectory (String filePath) {
		
		File file = new File(filePath);

		String[] archives = file.list(); 
		SimpleDateFormat simpleDate = new SimpleDateFormat("dd/MM/yyyy");

		try{
            //Abro stream y crear fichero
            FileWriter fw=new FileWriter("C:\\Users\\carlo\\OneDrive\\Escritorio\\prueba.txt");
            
            for(int i =0; i<archives.length; i++) {
		
            	fw.write("\n" + archives[i] + "(D)" + "  ->  Last time modified: " + simpleDate.format(file.lastModified())); 
				
            	File file2 = new File (file.getAbsolutePath(),archives[i]);

            	if (file2.isDirectory()) {
            		
            		String [] archives_subdirectory = file2.list();
				
            		for (int y= 0 ; y<archives_subdirectory.length; y++) {
            			fw.write("\n" + archives_subdirectory[y] + "(F)" + "  ->  Last time opened: " + simpleDate.format(file2.lastModified())); 
					}
            	}
			
            fw.close();
			}
	
			//Abro el stream
	        FileReader fr=new FileReader("C:\\Users\\carlo\\OneDrive\\Escritorio\\\\prueba.txt");
	        
	        //Leemos el fichero y lo mostramos por pantalla
	        int valor=fr.read();
        
	        while(valor!=-1){
	            System.out.print((char)valor);
	            valor=fr.read();
	        }
       
        	//Cerramos el stream
        	fr.close();
        }
		
		catch(IOException e){
            System.out.println("Error E/S: "+e);
        }	
	}
}


