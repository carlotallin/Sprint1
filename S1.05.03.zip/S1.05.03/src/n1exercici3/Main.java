package n1exercici3;

public class Main {
	
	public static void main(String[] args) {

		ListDirectory.listDirectory("C:\\Users\\carlo\\OneDrive\\Escritorio");
		
	}
	
}
