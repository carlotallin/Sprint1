package n1exercici3;

public class Main {
	
	public static void main(String[] args) {

		ListDirectory.saveListDirectoryTXT("C:\\Users\\carlo\\OneDrive\\Escritorio","directoryList");
		
	}

}
