package n1exercici3;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;

public class ListDirectory {

	static SimpleDateFormat simpleDate = new SimpleDateFormat("dd/MM/yyyy");

	//This method calls the listDirectory method. Saves a file with a chosen name(written through the parameters).
	public static void saveListDirectoryTXT (String filePath, String docName) {
		
		try { StringBuffer sbuffer = new StringBuffer ();
		      FileWriter myWriter = new FileWriter(filePath + "\\" + docName + ".txt");
		      listDirectory(filePath, 0, sbuffer);
		      myWriter.append(sbuffer);
		      myWriter.close();
		      System.out.println("\nSuccessfully wrote " + docName + " file. \nYou can find it here: " + filePath);
	    } 
		catch (IOException e) {
		      System.out.println("An error occurred. Check the file path and doc name.");
		      e.printStackTrace();
	    }	
	}
	
	public static String listDirectory(String filePath, int i, StringBuffer sbuffer) {
		
		//File with desktop archives
		File file = new File(filePath);
		String[] archives = file.list(); 

		//Stop the loop once all the archives have been printed
		if (i>=archives.length) 
			return " ";
		
		//Print archives
		sbuffer.append("\n" + archives[i] + "(D)" + "  ->  Last time modified: " + simpleDate.format(file.lastModified())); 
		
		//Method to list Subdirectories
		listSubdirectory(file, archives, i, 0, sbuffer);
		
		return listDirectory(filePath, i+1, sbuffer);	
	}
	
	public static String listSubdirectory (File file, String[] archives, int i, int y, StringBuffer sbuffer) {
		//File2 with subdirectories archives
		File file2 = new File (file.getAbsolutePath(),archives[i]);
		String [] archives_subdirectory = file2.list();

		//Print if there are subdirectories
		if (file2.isDirectory() && y<= archives_subdirectory.length-1) {
			//File3 with an specific archive of a subdirectory in order to print the specific date of the file and not the Subdirectory date. Each archive has an specific date.  
			File file3 = new File (file2.getAbsolutePath(),archives_subdirectory[y]);
			sbuffer.append("\n" + archives_subdirectory[y] + "(F)" +"  ->  Last time modified: " + simpleDate.format(file3.lastModified())); 
			
			return listSubdirectory( file, archives, i, y+1, sbuffer);
		}
		return "";
	}
	
}