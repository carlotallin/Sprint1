package n1exercici1_carlotaLlinas;

public class Main {

	public static void main(String[] args) {
	
		StringInstrument guitar = new StringInstrument("guitar",100);
		PercussionInstrument drum = new PercussionInstrument("drum",500);
		WindInstrument flute = new WindInstrument("flute",50);
		
		guitar.play();
		drum.play();
		flute.play();
		
		System.out.println ("\n" + guitar.toString() + 
							"\n" + drum.toString() + 
							"\n" + flute.toString());
		
	}

}
