package n1exercici1_carlotaLlinas;

public class PercussionInstrument extends Instrument {
	
	public PercussionInstrument (String name, float price) {
		super (name, price);
	}

	public void play() {
		System.out.println("A percussion instrument is playing.");	
	}
}
