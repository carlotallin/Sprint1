package n1exercici1_carlotaLlinas;

public class StringInstrument extends Instrument {
	
	public StringInstrument (String name, float price) {
		super (name, price);
	}
   
	public void play() {
		System.out.println("A Sting instrument is playing.");	
	}
}
