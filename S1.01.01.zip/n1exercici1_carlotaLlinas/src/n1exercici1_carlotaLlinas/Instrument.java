package n1exercici1_carlotaLlinas;

public abstract class Instrument {

	//Fields
	protected String name;
	protected float price;
	
	//Constructor
	public Instrument (String name, float price) {
		this.name = name;
		this.price = price;
	}
	
	//Methods
	public abstract void play();

	public String toString() {
		
		return "\n*** Instrument info ***" + "\nName: " + name + "\nPrice: " + price;
	}
}
