package n1exercici1_carlotaLlinas;

public class WindInstrument extends Instrument {

	public WindInstrument (String name, float price) {
		super (name, price);
	}
	
	public void play() {
		System.out.println("A wind instrument is playing.");	
	}
}


