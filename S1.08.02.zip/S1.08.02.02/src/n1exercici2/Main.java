package n1exercici2;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
	
	public static void main(String[] args) {
		
		//List
		List <String> wordsList = new ArrayList<>();
		 wordsList.add("car");
		 wordsList.add("motorbike");
		 wordsList.add("bike");
		 wordsList.add("plane");
		 wordsList.add("metro");
		 wordsList.add("rocket");
		 wordsList.add("boat");
		 wordsList.add("train");
		 wordsList.add("subway");
		 wordsList.add("scooter");
		 
		//Print list calling the method 
		System.out.println(listWordsLetterO(wordsList));		

	}

	public static List<String> listWordsLetterO (List<String> wordsList)  { 
	
		List<String> wordsLetterO = wordsList.stream()
											 .filter(x -> x.contains("o") && x.length()>5)
										 	 .collect(Collectors.toList());
		return wordsLetterO;	
    }

}
