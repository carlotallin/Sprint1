package n4exercici1;

import java.util.ArrayList;
import java.util.List;

public class Month {

	public static List<String> MonthList() {
		
		List<String> months = new ArrayList<String>();
		months.add("January");
		months.add("February");
		months.add("March");
		months.add("April");
		months.add("May");
		months.add("June");
		months.add("July");
		months.add("August");
		months.add("September");
		months.add("October");
		months.add("November");
		months.add("December");
		
		return months;
	}
}
