package n4exercici1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MonthTest {

	@Test
	void testArraySize() {
		
		int result = Month.MonthList().size();
		assertEquals(12, result);
	}
	
	@Test
	void testNotNull() {
		assertNotNull(Month.MonthList());
	}
	
	@Test
	void testEigthMonth() {
		String result = Month.MonthList().get(7); // 1st position = 0, so 8th position = 7th.
		
		assertEquals("August",result);
	}

}
