package n1exercici1;

public class Main {

	public static void main(String[] args) {

		//Els arguments es poden posar en qualsevol posició ja que tots són String.
		NoGenericMethods archives = new NoGenericMethods(3); //El nombre de valors de l'array el definim en el constructor
		
		archives.add("Sara");
		archives.add("Juan");
		archives.add("Pedro");
		
		System.out.println("\nFirst element: " + archives.get(1) + ".");
		archives.remove(archives.get(1)); 
		System.out.println("\nFirst element after calling the remove method: " + archives.get(1) + ".");

		//Cridar última posició de l'Array, sense element.
		System.out.println("\nLast element after removing one element: " + archives.get(2) + ".");
		
		//Afegir element a l'Array.
		archives.add("Paula");
		System.out.println("\nLast element after adding a new element: " + archives.get(2) + ".");

	}

}
