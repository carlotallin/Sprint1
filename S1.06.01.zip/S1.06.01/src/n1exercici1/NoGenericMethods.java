package n1exercici1;

public class NoGenericMethods {
	
	//Fields
	private int i = 0;
	private Object[] elements;

	//Constructor
	public NoGenericMethods (int z) {
		
		elements = new Object[z];
		
	}

	//Get element
	public Object get(int indice) {
		
		return elements[indice];
		
	}
	
	//Add element
	public void add (Object o) {
		
		elements[i]=o;
		i++;
		
	}
	
	//Eliminate element
	public void remove (Object o) {
				
			for (int index=0; index < elements.length; index++) {
				if (elements[index].equals(o) == true) {
					int newIndex= 0;
					for (int i = 0; newIndex <elements.length; i++ ) {	
						newIndex = index + i;
						if (newIndex<elements.length-1) {
						elements[newIndex]=elements[newIndex+1];}	
					}
					elements[elements.length-1]= "* There's no element in this position, add a new one. *";
					i--;
					System.out.println("\n* Object erased. *");
				}
			}
						
	}				
}
	

