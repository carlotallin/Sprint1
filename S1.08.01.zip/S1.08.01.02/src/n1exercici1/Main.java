package n1exercici1;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) {
		
		//List
		List <String> wordsList = new ArrayList<>();
		 wordsList.add("car");
		 wordsList.add("moto");
		 wordsList.add("bike");
		 wordsList.add("plane");
		 wordsList.add("metro");
		 wordsList.add("rocket");
		 wordsList.add("boat");
		 wordsList.add("train");
		 
		//Print list calling the method 
		System.out.println(listWordsLetterO(wordsList));		

	}

	public static List<String> listWordsLetterO (List<String> wordsList)  { 
	
		List<String> wordsLetterO = wordsList.stream()
											 .filter(x -> x.contains("o"))
										 	 .collect(Collectors.toList());
		return wordsLetterO;	
    }
	
}
