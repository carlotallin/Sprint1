package n1exercici1;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		List <String> wordsList = List.of("car", "moto","bike", "plane", "metro","rocket","boat","train");
		System.out.println(listWordsLetterO(wordsList));
	}

	public static List<String> listWordsLetterO (List<String> wordsList)  { 
		List<String> wordsLetterO = new ArrayList<>();   
	    for(String word:  wordsList){     
	    	if( word.contains("o")) {
	    		wordsLetterO.add(word);  
	    	}
	    }     
	    return wordsLetterO;   
    }
	
}
