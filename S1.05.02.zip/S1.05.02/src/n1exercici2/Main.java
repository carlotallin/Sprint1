package n1exercici2;

public class Main {

	public static void main(String[] args) {

		ListDirectory.listDirectory("C:\\Users\\carlo\\OneDrive\\Escritorio");
		
	}
}
