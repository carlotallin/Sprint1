package n1exercici2;

import java.io.File;
import java.text.SimpleDateFormat;

public class ListDirectory {
	

	public static void listDirectory (String filePath) {
		
		File file = new File(filePath);

		String[] archives = file.list(); 
		SimpleDateFormat simpleDate = new SimpleDateFormat("dd/MM/yyyy");

		for(int i =0; i<archives.length; i++) {
			System.out.println("\n" + archives[i] + "(D)" + 
					"  ->  Last time modified: " + simpleDate.format(file.lastModified()) ); 
				
			File file2 = new File (file.getAbsolutePath(),archives[i]);

			if (file2.isDirectory()) {
				String [] archives_subdirectory = file2.list();
				
				for (int y= 0 ; y<archives_subdirectory.length; y++) {
					System.out.println(archives_subdirectory[y] + "(F)" +
					"  ->  Last time opened: " + simpleDate.format(file2.lastModified())); 
				}
			}
		}
	}
}