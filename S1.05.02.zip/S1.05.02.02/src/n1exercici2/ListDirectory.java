package n1exercici2;

import java.io.File;
import java.text.SimpleDateFormat;

public class ListDirectory {
	
	static SimpleDateFormat simpleDate = new SimpleDateFormat("dd/MM/yyyy");

	public static String listDirectory(String filePath, int i) {

		//File with desktop archives
		File file = new File(filePath);
		String[] archives = file.list(); 

		//Stop the loop once all the archives have been printed
		if (i>=archives.length) 
			return " ";
		
		//Print archives
		System.out.println("\n" + archives[i] + "(D)" + "  ->  Last time modified: " + simpleDate.format(file.lastModified())); 
		
		//Method to list Subdirectories
		listSubdirectory(file, archives, i, 0);
		
		return listDirectory(filePath, i+1);	
	}
	
	public static String listSubdirectory (File file, String[] archives, int i, int y) {
		//File2 with subdirectories archives
		File file2 = new File (file.getAbsolutePath(),archives[i]);
		String [] archives_subdirectory = file2.list();

		//Print if there are subdirectories
		if (file2.isDirectory() && y<= archives_subdirectory.length-1) {
			//File3 with an specific archive of a subdirectory in order to print the specific date of the file and not the Subdirectory date. Each archive has an specific date.  
			File file3 = new File (file2.getAbsolutePath(),archives_subdirectory[y]);
			System.out.println(archives_subdirectory[y] + "(F)" +"  ->  Last time modified: " + simpleDate.format(file3.lastModified())); 
			
			return listSubdirectory( file, archives, i, y+1);
		}
		return "";
	}
	
}