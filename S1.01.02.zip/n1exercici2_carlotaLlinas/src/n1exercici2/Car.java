package n1exercici2;

public class Car {

	private static final String brand = "four";
	private static String model = "aisdk";
	private final int potencia = 5000;
	
	public Car (String model) {
		Car.model = model;
	}
	
	public static String stop() {
		return "The vehicle is stopping.";
	}
	
	public String accelerate () {
		return "The vehicle is accelerating.";
	}

	public String toString(){
		return "\n*** Car info ***" + "\nBrand: " + Car.brand + "\nModel: " + Car.model + "\nPotencia: " + potencia;
	}
	
}
