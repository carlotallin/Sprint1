package n1exercici2;

public class Car {

	/* Private indica que sólo está accesible a los métodos de la misma clase en la que la variable se ha declarado.
	Static el atributo pertenece a la clase, no al objeto.
	Final variable constante, no se puede modificar. */
	
	//FIELDS
	private static final String brand = "four"; //Asignar valor al principio ya que afecta a toda la clase y su valor no se puede modificar al ser final.
	private static String model; //Afecta a toda la clase, pero se puede cambiar a través de un método (no es final).
	private final int power; // se puede inicilizar en el constructor
	
	//CONSTRUCTOR
	public Car (int power) { //Atributo que afecta al Objeto
		model = "2022L"; //Afecta a la clase
		this.power = power; 
	}
	
	//GETTERS
	public static String getModel() {
		return model;
	}
	public int getPower() {
		return power;
	}
	public static String getBrand() {
		return brand;
	}	
	
	//METHODS
	public static String stop() {
		return "The vehicle is stopping.";
	}
	public String accelerate () {
		return "The vehicle is accelerating.";
	}
	public String toString(){
		return "\n*** Car info ***" + "\nBrand: " + Car.brand + "\nModel: " + Car.model + "\nPotencia: " + power;
	}
	
}
