package n1exercici2;

public class Main {

	public static void main(String[] args) {
		
		Car car = new Car(4000);
		
		//Cridem al mètode static a través de la classe
		System.out.println(Car.stop());
		//El mètode el cridem a través de l'objecte
		System.out.println(car.accelerate());
		
		System.out.println(car.toString());
	}
}


