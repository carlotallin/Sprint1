package n4exercici2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculateDniTest {

	@Test
	void testCalculoDni(int dniNumber, String dniLetter) {
		 //Ejemplo real 
		 dniNumber=21759404;
		 dniLetter= "R";
		 String foundLetter = CalculateDni.calculateLetter(dniNumber);
		 assertEquals(dniLetter, foundLetter);
	 }
}
