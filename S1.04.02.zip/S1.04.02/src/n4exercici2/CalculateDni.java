package n4exercici2;

public class CalculateDni {

	public static void main(String[] args) {
		
		System.out.println ("Your Dni letter is:" + calculateLetter(21759404));
		
	}
	
	public static String calculateLetter(int numberDni) {
		
		int rest = numberDni%23;
		String letterDni = "";
		
			switch (rest) {
				case 0: letterDni = "T"; 
						break;
				case 1: letterDni = "R"; 
						break;
				case 2: letterDni = "W"; 
						break;
				case 3: letterDni = "A"; 
						break;
				case 4: letterDni = "G"; 
						break;
				case 5: letterDni = "M"; 
						break;
				case 6: letterDni = "Y"; 
						break;
				case 7: letterDni = "F"; 
						break;
				case 8: letterDni = "P"; 
						break;
				case 9: letterDni = "D"; 
						break;
				case 10: letterDni = "X"; 
						break;
				case 11: letterDni = "B"; 
						break;
				case 12: letterDni = "N"; 
						break;
				case 13: letterDni = "J"; 
						break;
				case 14: letterDni = "Z"; 
						break;
				case 15: letterDni = "S"; 
						break;
				case 16: letterDni = "Q"; 
						break;
				case 17: letterDni = "V"; 
						break;
				case 18: letterDni = "H"; 
						break;
				case 19: letterDni = "L"; 
						break;
				case 20: letterDni = "C"; 
						break;
				case 21: letterDni = "K"; 
						break;
				case 22: letterDni = "E"; 
						break;
				default: System.out.println("Write a valid number.");
			}	
		return letterDni;		
	}
}
