package n3exercici2_carlotaLlinas;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class Main {

	public static void main(String[] args) {
	
		//Primera lista
		List<Integer> list =new ArrayList<Integer>();	
		for (int i = 0; i<10; i++) 
			{list.add(i);}
		
		System.out.println(list.toString());
		
		//Segunda lista
		List<Integer> list2 =new ArrayList<Integer>();
		for (int i = 9; i>=0; i--) 
			{list2.add(i);}
		
		ListIterator <Integer> litr = list2.listIterator();		
		while (litr.hasNext()) {
			System.out.print(litr.next());}
	
		System.out.println(""); //Espacio entre listas
		
		//Tercera lista. Lista 2 + elementos de lista 1
		ListIterator<Integer> list3 = list.listIterator();
		
		for (int i = 9; i>=0; i--)
			{list3.add(i);}
		
		for (Integer i: list) 
			{System.out.print(i);}
		
	
		
	}
}
