package n1exercici5;

@FunctionalInterface
public interface Interface {
		
		public double getPiValue();
		
}
