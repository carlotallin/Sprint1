package n1exercici5;

public class Main {

	public static void main(String[] args) {

		Interface instancia = () -> {return 3.1415;};
		System.out.println(instancia.getPiValue());
		
	}
}


