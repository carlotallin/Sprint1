package n1exercici1;

public class Main {

	public static void main(String[] args) {

		ListDirectory listDirectory = new ListDirectory();
		listDirectory.listDirectory("C:\\Users\\carlo\\OneDrive\\Escritorio");
		
	}
}
