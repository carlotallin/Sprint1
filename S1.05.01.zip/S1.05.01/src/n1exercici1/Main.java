package n1exercici1;

public class Main {

	public static void main(String[] args) {

		ListDirectory.listDirectory("C:\\Users\\carlo\\OneDrive\\Escritorio");
		
	}
}
