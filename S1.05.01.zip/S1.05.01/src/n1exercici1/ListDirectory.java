package n1exercici1;

import java.io.File;
import java.util.Arrays;


public class ListDirectory {
	
	public void listDirectory (String filePath) {
		
		File file = new File(filePath);
		String[] archives = file.list(); 
		Arrays.sort(archives);
		
		if (archives != null) {
			printArchives(archives, 0);			
		}
		else {
			System.out.println("There's an error, please try again.");
		}	
	}

	public void printArchives (String[] archives, int index) {
		
		if (index < archives.length) {
			System.out.println(archives[index]);
		
		printArchives(archives, (index+1));}	
	}
}
