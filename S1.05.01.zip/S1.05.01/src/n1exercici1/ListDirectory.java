package n1exercici1;

import java.io.File;
import java.util.Arrays;


public class ListDirectory {
	
	public void listDirectory (String filePath) {
		
		File file = new File(filePath);
		String[] archives = file.list(); 
		Arrays.sort(archives);
		
		if (archives != null) {
			for(String s : archives){
				System.out.println(s);
			}		
		}
		else {
			System.out.println("There's an error, please try again. Check the file path.");
		}		
	}
}
