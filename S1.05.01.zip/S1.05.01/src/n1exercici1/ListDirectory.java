package n1exercici1;

import java.io.File;

public class ListDirectory {
	
	public static void listDirectory (String filePath) {
		
		File file = new File(filePath);

		String[] archives = file.list(); 
		
		for(int i =0; i<archives.length; i++) {
			System.out.println(archives[i]); // Imprime ya en orden la lista
		}
		
	}

}
