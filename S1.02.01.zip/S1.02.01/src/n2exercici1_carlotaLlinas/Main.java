package n2exercici1_carlotaLlinas;

import java.util.ArrayList;

public class Main {

    static ArrayList <Product> productCollection = new ArrayList<>();
    static ArrayList <Product> productCollection2 = new ArrayList<>();

	public static void main(String[] args) {
		
		Selling sale = new Selling(productCollection);
		Selling sale2 = new Selling(productCollection2);

		Product product1 = new Product("Book", 10);
		Product product2 = new Product("Chair", 15);
		Product product3 = new Product("Table", 35);


		sale.getProductCollection().add(product1);
		sale.getProductCollection().add(product2);
		sale.getProductCollection().add(product3);
		
		//Calculate total sale 1  
		sale.calculateTotal();
		
		//Calculate total sale 2 (EmptyListException example)
		sale2.calculateTotal();
		
		//Trying to get an element that doesn't exist (IndexOutOfException example) 
		try {sale.getProductCollection().get(4);
		}
		catch(IndexOutOfBoundsException e) { 
			System.out.println("** " + e.getMessage() + " **");
		}
	}
}




