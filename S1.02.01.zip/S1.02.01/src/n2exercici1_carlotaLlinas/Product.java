package n2exercici1_carlotaLlinas;

public class Product {

	//FIELDS
	private String name;
	private float price;	

	//CONSTRUCTOR
	public Product (String name, float price) {
		this.name=name;
		this.price=price;
	}
	
	//GETTERS AND SETTERS
	public String getName() {
		return name;
	}
	public float getPrice() {
		return price;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPrice(float price) {
		this.price = price;
	}
}