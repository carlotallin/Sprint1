package n2exercici1_carlotaLlinas;

@SuppressWarnings("serial")
public class EmptySaleException extends Exception {

	public EmptySaleException (String errorMessage)
		{ super (errorMessage);}
	
}
