package n2exercici1_carlotaLlinas;
import java.util.ArrayList;

public class Selling {

	//Fields
	private float totalPriceSold;
	private ArrayList <Product> productCollection;
	
	//Constructor
	public Selling (ArrayList<Product> productCollection) {
		this.productCollection = productCollection;
		this.totalPriceSold=0;
	}
	
	//Getters and setters
	public ArrayList <Product> getProductCollection() {
		return productCollection;
	}
	public void setProductCollection(ArrayList <Product> productCollection) {
		this.productCollection = productCollection;
	}
	
	//Methods
	public void calculateTotal(){
		int index; 
		float priceProduct;
		
		try {
			if (productCollection.size()>0) {
				for (index = 0; index < getProductCollection().size(); index++) 
				{
					priceProduct = getProductCollection().get(index).getPrice(); 
					totalPriceSold += priceProduct;
					}
				System.out.println("Total win: " + totalPriceSold + "€.\n");
			} 
			else {
				EmptySaleException emptySaleException = new EmptySaleException("** You need to add products to the list to calculate the total price. **\n");
				throw emptySaleException;}
		}
		catch (Exception emptySaleException) {
			System.out.println(emptySaleException.getMessage());
		}
	}
}