package n1exercici3;

import org.junit.jupiter.api.Test;

class ExceptionTest {

	@Test//(expected = ArrayIndexOutOfBoundsException.class)
	void testNumeroMayor(){
		try {
			Exception.months();
			}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		 	}	
	}

}
