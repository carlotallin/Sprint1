package n1exercici3;

public class Exception {

	public static void months() throws ArrayIndexOutOfBoundsException{
		String months[] = {" ","january","february","march","april","may","june","july","august","september","october","november","december"};
		
		try {
			for (int i = 1; i < months.length+1; i++) { //Imprimir lista hasta el índice 13 para que salte Exception
				System.out.println("Month with index " + i + ": " + months[i]);
				}
			}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Please enter an index number between 0 and 11.");
			}			
	}
	
}
