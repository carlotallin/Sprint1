package n1exercici8;

@FunctionalInterface
public interface Interface {

	public String reverse(String word);
	
}
