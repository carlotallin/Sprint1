package n1exercici4;

public class Main {
	
	public static void main(String[] args) {
		
		/* COMMENTED TO SEE JUST THE NEW METHOD
		ListDirectory.listDirectory("C:\\Users\\carlo\\OneDrive\\Escritorio",0);
		System.out.println("\n\n\n");
		*/
		
		//READ TEXT FILE AND SHOW IT METHOD
		ReadTXTFile access = new ReadTXTFile();
		access.readFile("C:/Users/carlo/OneDrive/Escritorio/Countries.txt");
		
	}
	
}
