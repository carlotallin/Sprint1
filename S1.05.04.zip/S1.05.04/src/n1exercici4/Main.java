package n1exercici4;

public class Main {
	
	public static void main(String[] args) {

		
		ListDirectory acessList = new ListDirectory();
		acessList.listDirectory("C:\\Users\\carlo\\OneDrive\\Escritorio");
		
		System.out.println("\n\n\n");
		
		ReadTXTFile access = new ReadTXTFile();
		access.readFile("C:/Users/carlo/OneDrive/Escritorio/Countries.txt");
		
	}
	
}
