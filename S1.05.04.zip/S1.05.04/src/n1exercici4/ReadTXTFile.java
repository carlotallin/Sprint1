package n1exercici4;

import java.io.FileReader;
import java.io.IOException;

public class ReadTXTFile {

	public void readFile(String filePath) {
		
		try {
			FileReader entry = new FileReader(filePath);
			int c=entry.read();
			while (c!=-1) {
				c=entry.read();
				char letter = (char)c;
				System.out.print(letter);
			}
			entry.close();			
		} 
		catch (IOException e) {
			System.out.println("Couldn't find the file, please try again.");
		} 
	}	
}
 