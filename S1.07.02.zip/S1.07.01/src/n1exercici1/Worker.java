package n1exercici1;

public class Worker {

	//Fields
	protected String name;
	protected String surname;
	protected int priceHour;

	//Constructor
	public Worker(String name, String surname, int priceHour) {
		this.name = name;
		this.surname = surname;
		this.priceHour = priceHour;
	}

	// Getters and Setters
	public String getName() {
		return name;
	}
	public String getSurname() {
		return surname;
	}
	public int getPriceHour() {
		return priceHour;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public void setPriceHour(int priceHour) {
		this.priceHour = priceHour;
	}
	
	//Methods
	public String calculateSalary (int hours) {
		
		double salary;
		salary = hours * priceHour;
		
		return name + " " + surname  + " has a monthly salary of: " + salary + "€.";
	}
}
