package n1exercici1;

public class PhysicalWorker extends Worker {

	// Fields
	private static double gasolineCost;
	
	//Constructor
	public PhysicalWorker(String name, String surname, int priceHour) {
		super(name, surname, priceHour);
		gasolineCost = 98.25;
	}
	
	//Getters and Setters
	public static double getGasolineCost() {
		return gasolineCost;
	}
	
	public static void setGasolineCost(double gasolineCost) {
		PhysicalWorker.gasolineCost = gasolineCost;
	}
	
	@Deprecated
	public String calculateSalary (double hours) {
		
		double salary;
		salary = (hours * priceHour) + gasolineCost;
		
		return name + " " + surname  + " has a monthly salary of: " + salary + "€.";
	}
	
	@Override	
	public String calculateSalary (int hours) {
		
		double salary;
		salary = (hours * priceHour) + gasolineCost;
		
		return name + " " + surname  + " has a monthly salary of: " + salary + "€.";
	}
	
	

}
