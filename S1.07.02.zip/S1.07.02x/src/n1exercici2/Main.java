package n1exercici2;

public class Main {

	public static void main(String[] args) {
		
		Worker worker = new Worker("Carlota","Llinàs",12);
		OnlineWorker onlineWorker = new OnlineWorker("Biel","Bernad",16,38.58);
		PhysicalWorker physicalWorker = new PhysicalWorker("Sara","Gabarró",13);

		System.out.println(worker.calculateSalary(160));
		System.out.println(onlineWorker.calculateSalary(160));
		System.out.println(physicalWorker.calculateSalary(160));

	}

}
