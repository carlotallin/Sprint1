package n1exercici2;

public class PhysicalWorker extends Worker {

	// Fields
	private static double gasolineCost;
	
	//Constructor
	public PhysicalWorker(String name, String surname, int priceHour) {
		super(name, surname, priceHour);
		gasolineCost = 98.25;
	}
	
	@Override	
	public String calculateSalary (int hours) {
		
		double salary;
		salary = (hours * priceHour) + gasolineCost;
		
		return name + " " + surname  + " has a monthly salary of: " + salary + "€.\n";
	}
}
