package n1exercici2;

public class OnlineWorker extends Worker {

	//Fields
	private final double internetPrice;
	
	//Constructor
	public OnlineWorker(String name, String surname, int priceHour, double internetPrice) {
		super(name, surname, priceHour);
		this.internetPrice = internetPrice;
	}
	
	@Override
	public String calculateSalary (int hours) {
		
		double salary;
		salary = (hours * priceHour) + internetPrice;
		
		return name + " " + surname  + " has a monthly salary of: " + salary + "€.\n";
	}
}
