package n3exercici1;

public class Month {

	private String monthName;
	
	public Month (String monthName) {
		this.monthName = monthName;
	}
	
	public String getMonthName() {
		return monthName;
	}
}
