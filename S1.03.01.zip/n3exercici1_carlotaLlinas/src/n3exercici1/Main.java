package n3exercici1;

//import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class Main {

	public static void main(String[] args) {

		Month month1 = new Month ("january");  
		Month month2 = new Month ("february");  
		Month month3 = new Month ("march");  
		Month month4 = new Month ("april");  
		Month month5 = new Month ("may");  
		Month month6 = new Month ("june");  
		Month month7 = new Month ("july"); 
		Month month8 = new Month ("august");  
		Month month9 = new Month ("september");  
		Month month10 = new Month ("october");  
		Month month11 = new Month ("november");  
		Month month12 = new Month ("december");  

		/* 
		 
		**** ARRAY LIST ****
		
		ArrayList <Month> monthList = new ArrayList<Month>();

		monthList.add(month1);
		monthList.add(month2);
		monthList.add(month3);
		monthList.add(month4);
		monthList.add(month5);
		monthList.add(month6);
		monthList.add(month7);
		monthList.add(month9);
		monthList.add(month10);
		monthList.add(month11);
		monthList.add(month12);
		monthList.add(7, month8); //Nuevo elemento en posición concreta en la lista
		
		for (int index = 0; index < monthList.size();index++)
		{System.out.println(monthList.get(index).getMonthName());}
	
		 */
		
		
		// **** HASHSET ****
		
		HashSet<Month> monthList = new HashSet<Month>();
		
		monthList.add(month1);
		monthList.add(month2);
		monthList.add(month3);
		monthList.add(month4);
		monthList.add(month5);
		monthList.add(month6);
		monthList.add(month7);
		monthList.add(month8);
		monthList.add(month9);
		monthList.add(month10);
		monthList.add(month11);
		monthList.add(month12);
		
		// **Duplicados**, demostración que un Set no permite elementos duplicados
		monthList.add(month8); 
		monthList.add(month9);
		monthList.add(month10);
		
		//Iterator
		Iterator <Month> iterator = monthList.iterator();
		
		while (iterator.hasNext()) {
			String monthName=iterator.next().getMonthName();
			System.out.println(monthName);
		}		
		
		System.out.println("\n");

		//For
		for (Object element : monthList) 
			{Month x = (Month)element;
			System.out.println(x.getMonthName());
			}
		
		System.out.println("\nNumber of elements inside this set: " + monthList.size());
	}
}
